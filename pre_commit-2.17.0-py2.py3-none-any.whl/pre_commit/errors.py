class FatalError(RuntimeError):
    pass
